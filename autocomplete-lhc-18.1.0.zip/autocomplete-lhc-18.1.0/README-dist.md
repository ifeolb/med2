Zip file distributions of this package come with three versions of the
minified JavaScript file.  The smallest file contains just this package, without
the jQuery and jQuery UI dependencies.

Use:
  * autocomplete-lhc.min.js if your website already has jQuery and jQuery UI
  * autocomplete-lhc_jQueryUI.min.js if you also need the jQuery UI components
  * autocomplete-lhc_jQuery.min.js if you need jQuery as well as jQuery UI

Note that the package can also be installed with the [bower](http://bower.io)
package manager, via "bower install autocomplete-lhc".
